# coding:utf-8
import random
from datetime import datetime
from sqlalchemy import text,TIMESTAMP

from api.models.models import Base_model
from api.exts import db
from sqlalchemy.dialects.mysql import DOUBLE,LONGTEXT
# 个人信息
class jiaoshi(Base_model):
    __doc__ = u'''jiaoshi'''
    __tablename__ = 'jiaoshi'

    __loginUser__='jiaoshigonghao'


    __authTables__={}
    __authPeople__='是'
    __authSeparate__='否'
    __thumbsUp__='否'
    __intelRecom__='否'
    __browseClick__='否'
    __foreEndListAuth__='否'
    __foreEndList__='否'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    jiaoshigonghao=db.Column( db.VARCHAR(255), nullable=False,unique=True,comment='教师工号' )
    mima=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='密码' )
    xingbie=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='性别' )
    jiaoshixingming=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='教师姓名' )
    zhaopian=db.Column( db.Text,  nullable=True, unique=False,comment='照片' )
    zhicheng=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='职称' )
    lianxidianhua=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='联系电话' )

class zhujiao(Base_model):
    __doc__ = u'''zhujiao'''
    __tablename__ = 'zhujiao'

    __loginUser__='zhujiaogonghao'


    __authTables__={}
    __authPeople__='是'
    __authSeparate__='否'
    __thumbsUp__='否'
    __intelRecom__='否'
    __browseClick__='否'
    __foreEndListAuth__='否'
    __foreEndList__='否'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    zhujiaogonghao=db.Column( db.VARCHAR(255), nullable=False,unique=True,comment='助教工号' )
    mima=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='密码' )
    xingbie=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='性别' )
    touxiang=db.Column( db.Text,  nullable=True, unique=False,comment='头像' )
    zhicheng=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='职称' )
    zhujiaoxingming=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='助教姓名' )
    lianxidianhua=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='联系电话' )

class xuesheng(Base_model):
    __doc__ = u'''xuesheng'''
    __tablename__ = 'xuesheng'

    __loginUser__='xuehao'


    __authTables__={}
    __authPeople__='是'
    __authSeparate__='否'
    __thumbsUp__='否'
    __intelRecom__='否'
    __browseClick__='否'
    __foreEndListAuth__='否'
    __foreEndList__='否'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    xuehao=db.Column( db.VARCHAR(255), nullable=False,unique=True,comment='学号' )
    mima=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='密码' )
    xingming=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='姓名' )
    xingbie=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='性别' )
    touxiang=db.Column( db.Text,  nullable=True, unique=False,comment='头像' )
    shouji=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='手机' )
    banji=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='班级' )

class zhishigainian(Base_model):
    __doc__ = u'''zhishigainian'''
    __tablename__ = 'zhishigainian'



    __authTables__={}
    __authPeople__='否'
    __authSeparate__='否'
    __thumbsUp__='是'
    __intelRecom__='否'
    __browseClick__='是'
    __foreEndListAuth__='否'
    __foreEndList__='是'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    mingcheng=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='名称' )
    leixing=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='类型' )
    tupian=db.Column( db.Text,  nullable=True, unique=False,comment='图片' )
    wenjian=db.Column( db.Text,  nullable=True, unique=False,comment='文件' )
    riqi=db.Column( db.Date,  nullable=True, unique=False,comment='日期' )
    neirong=db.Column( db.Text,  nullable=True, unique=False,comment='内容' )
    thumbsupnum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='赞' )
    crazilynum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='踩' )
    clicknum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='点击次数' )
    discussnum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='评论数' )
    storeupnum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='收藏数' )

class tijiaoxinxi(Base_model):
    __doc__ = u'''tijiaoxinxi'''
    __tablename__ = 'tijiaoxinxi'



    __authTables__={'xuehao':'xuesheng',}
    __authPeople__='否'
    __authSeparate__='否'
    __thumbsUp__='否'
    __intelRecom__='否'
    __browseClick__='否'
    __foreEndListAuth__='否'
    __foreEndList__='否'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    tijiaomingcheng=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='提交名称' )
    tupianxinxi=db.Column( db.Text,  nullable=True, unique=False,comment='图片信息' )
    tijiaoleixing=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='提交类型' )
    wenjianxinxi=db.Column( db.Text,  nullable=True, unique=False,comment='文件信息' )
    tijiaoneirong=db.Column( db.Text,  nullable=True, unique=False,comment='提交内容' )
    tijiaoriqi=db.Column( db.Date,  nullable=True, unique=False,comment='提交日期' )
    xuehao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='学号' )
    xingming=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='姓名' )
    shouji=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='手机' )

class zhujiaodafen(Base_model):
    __doc__ = u'''zhujiaodafen'''
    __tablename__ = 'zhujiaodafen'



    __authTables__={'xuehao':'xuesheng','zhujiaogonghao':'zhujiao',}
    __authPeople__='否'
    __authSeparate__='否'
    __thumbsUp__='否'
    __intelRecom__='否'
    __browseClick__='否'
    __foreEndListAuth__='否'
    __foreEndList__='否'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    tijiaomingcheng=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='提交名称' )
    tupianxinxi=db.Column( db.Text,  nullable=True, unique=False,comment='图片信息' )
    chengji=db.Column( db.Float,default=0, nullable=False, unique=False,comment='成绩' )
    dafenshuoming=db.Column( db.Text,  nullable=True, unique=False,comment='打分说明' )
    dafenriqi=db.Column( db.Date,  nullable=True, unique=False,comment='打分日期' )
    xuehao=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='学号' )
    xingming=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='姓名' )
    zhujiaogonghao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='助教工号' )
    crossuserid=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='跨表用户id' )
    crossrefid=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='跨表主键id' )

class jiaoshidafen(Base_model):
    __doc__ = u'''jiaoshidafen'''
    __tablename__ = 'jiaoshidafen'



    __authTables__={'xuehao':'xuesheng','jiaoshigonghao':'jiaoshi',}
    __authPeople__='否'
    __authSeparate__='否'
    __thumbsUp__='否'
    __intelRecom__='否'
    __browseClick__='否'
    __foreEndListAuth__='否'
    __foreEndList__='否'
    __isAdmin__='否'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    tijiaomingcheng=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='提交名称' )
    tupianxinxi=db.Column( db.Text,  nullable=True, unique=False,comment='图片信息' )
    chengji=db.Column( db.Float,default=0, nullable=False, unique=False,comment='成绩' )
    dafenriqi=db.Column( db.Date,  nullable=True, unique=False,comment='打分日期' )
    xuehao=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='学号' )
    jiaoshigonghao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='教师工号' )
    xingming=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='姓名' )
    crossuserid=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='跨表用户id' )
    crossrefid=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='跨表主键id' )

class forum(Base_model):
    __doc__ = u'''forum'''
    __tablename__ = 'forum'



    __authTables__={}
    __foreEndListAuth__='是'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    title=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='帖子标题' )
    content=db.Column( db.Text, nullable=False, unique=False,comment='帖子内容' )
    parentid=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='父节点id' )
    userid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='用户id' )
    username=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='用户名' )
    avatarurl=db.Column( db.Text,  nullable=True, unique=False,comment='头像' )
    isdone=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='状态' )
    istop=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='是否置顶' )
    toptime=db.Column( db.DateTime,  nullable=True, unique=False,comment='置顶时间' )

class exampaper(Base_model):
    __doc__ = u'''exampaper'''
    __tablename__ = 'exampaper'



    __authTables__={'jiaoshigonghao':'jiaoshi',}
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    name=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='测试信息名称' )
    time=db.Column( db.Integer,default=0, nullable=False, unique=False,comment='学习测试时长(分钟)' )
    status=db.Column( db.Integer,default=0, nullable=False, unique=False,comment='测试信息状态' )
    jiaoshigonghao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='教师工号' )

class examquestion(Base_model):
    __doc__ = u'''examquestion'''
    __tablename__ = 'examquestion'



    __authTables__={'jiaoshigonghao':'jiaoshi',}
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    paperid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='所属测试信息id（外键）' )
    papername=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='测试信息名称' )
    questionname=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='测试题目名称' )
    options=db.Column( db.Text,  nullable=True, unique=False,comment='选项，json字符串' )
    score=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='分值' )
    answer=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='正确答案' )
    analysis=db.Column( db.Text,  nullable=True, unique=False,comment='答案解析' )
    type=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='测试题目类型，0：单选题 1：多选题 2：判断题 3：填空题（暂不考虑多项填空）4:主观题' )
    sequence=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='测试题目排序，值越大排越前面' )
    jiaoshigonghao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='教师工号' )

class examquestionbank(Base_model):
    __doc__ = u'''examquestionbank'''
    __tablename__ = 'examquestionbank'



    __authTables__={'jiaoshigonghao':'jiaoshi',}
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    questionname=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='测试题目名称' )
    options=db.Column( db.Text,  nullable=True, unique=False,comment='选项，json字符串' )
    score=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='分值' )
    answer=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='正确答案' )
    analysis=db.Column( db.Text,  nullable=True, unique=False,comment='答案解析' )
    type=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='测试题目类型，0：单选题 1：多选题 2：判断题 3：填空题（暂不考虑多项填空） 4:主观题' )
    sequence=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='测试题目排序，值越大排越前面' )
    jiaoshigonghao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='教师工号' )

class examrecord(Base_model):
    __doc__ = u'''examrecord'''
    __tablename__ = 'examrecord'



    __authTables__={'jiaoshigonghao':'jiaoshi',}
    __authSeparate__='是'
    __foreEndListAuth__='是'
    __examinationPaper__='是'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    userid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='用户id' )
    username=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='用户名' )
    paperid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='测试信息id（外键）' )
    papername=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='测试信息名称' )
    questionid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='测试题目id（外键）' )
    questionname=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='测试题目名称' )
    options=db.Column( db.Text,  nullable=True, unique=False,comment='选项，json字符串' )
    score=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='分值' )
    answer=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='正确答案' )
    analysis=db.Column( db.Text,  nullable=True, unique=False,comment='答案解析' )
    ismark=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='是否批卷' )
    type=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='测试题目类型，0：单选题 1：多选题 2：判断题 3：填空题（暂不考虑多项填空） 4:主观题' )
    myscore=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='测试题目得分' )
    myanswer=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='考生答案' )
    jiaoshigonghao=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='教师工号' )

class newstype(Base_model):
    __doc__ = u'''newstype'''
    __tablename__ = 'newstype'



    __authTables__={}
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    typename=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='分类名称' )

class news(Base_model):
    __doc__ = u'''news'''
    __tablename__ = 'news'



    __authTables__={}
    __thumbsUp__='是'
    __intelRecom__='是'
    __browseClick__='是'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    title=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='标题' )
    introduction=db.Column( db.Text,  nullable=True, unique=False,comment='简介' )
    typename=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='分类名称' )
    name=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='发布人' )
    headportrait=db.Column( db.Text,  nullable=True, unique=False,comment='头像' )
    clicknum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='点击次数' )
    clicktime=db.Column( db.DateTime,  nullable=True, unique=False,comment='最近点击时间' )
    thumbsupnum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='赞' )
    crazilynum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='踩' )
    storeupnum=db.Column( db.Integer,default=0,  nullable=True, unique=False,comment='收藏数' )
    picture=db.Column( db.Text, nullable=False, unique=False,comment='图片' )
    content=db.Column( db.Text, nullable=False, unique=False,comment='内容' )

class storeup(Base_model):
    __doc__ = u'''storeup'''
    __tablename__ = 'storeup'



    __authTables__={}
    __authSeparate__='是'
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    userid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='用户id' )
    refid=db.Column( db.BigInteger,default=0,  nullable=True, unique=False,comment='商品id' )
    tablename=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='表名' )
    name=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='名称' )
    picture=db.Column( db.Text,  nullable=True, unique=False,comment='图片' )
    type=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='类型' )
    inteltype=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='推荐类型' )
    remark=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='备注' )

class aboutus(Base_model):
    __doc__ = u'''aboutus'''
    __tablename__ = 'aboutus'



    __authTables__={}
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    title=db.Column( db.VARCHAR(255), nullable=False, unique=False,comment='标题' )
    subtitle=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='副标题' )
    content=db.Column( db.Text, nullable=False, unique=False,comment='内容' )
    picture1=db.Column( db.Text,  nullable=True, unique=False,comment='图片1' )
    picture2=db.Column( db.Text,  nullable=True, unique=False,comment='图片2' )
    picture3=db.Column( db.Text,  nullable=True, unique=False,comment='图片3' )

class discusszhishigainian(Base_model):
    __doc__ = u'''discusszhishigainian'''
    __tablename__ = 'discusszhishigainian'



    __authTables__={}
    id = db.Column(db.BigInteger, primary_key=True,autoincrement=False,comment='主键')
    addtime = db.Column(TIMESTAMP, server_default=text('CURRENT_TIMESTAMP'), server_onupdate=text('CURRENT_TIMESTAMP'))
    refid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='关联表id' )
    userid=db.Column( db.BigInteger,default=0, nullable=False, unique=False,comment='用户id' )
    avatarurl=db.Column( db.Text,  nullable=True, unique=False,comment='头像' )
    nickname=db.Column( db.VARCHAR(255),  nullable=True, unique=False,comment='用户名' )
    content=db.Column( db.Text, nullable=False, unique=False,comment='评论内容' )
    reply=db.Column( db.Text,  nullable=True, unique=False,comment='回复内容' )

