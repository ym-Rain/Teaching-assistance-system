const base = {
    get() {
        return {
            url : "http://localhost:8080/pythonx94y062i/",
            name: "pythonx94y062i",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/front/dist/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "教学辅助系统"
        } 
    }
}
export default base
