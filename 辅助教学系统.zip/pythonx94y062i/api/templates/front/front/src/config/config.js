export default {
    baseUrl: 'http://localhost:8080/pythonx94y062i/',
	name: '/pythonx94y062i',
    indexNav: [
        {
            name: '知识概念',
            url: '/index/zhishigainian'
        },
        {
            name: '论坛交流',
            url: '/index/forum'
        }, 
        {
            name: '测试信息',
            url: '/index/examPaper'
        }, 
        {
            name: '公告资讯',
            url: '/index/news'
        },
    ]
}
