<template>
<div class="center-preview" :style='{"width":"80%","margin":"10px auto","position":"relative","background":"none"}'>
	<div class="title" :style='{"border":"2px solid #57A7A5","margin":"0","color":"#57A7A5","textAlign":"center","background":"#fff","fontSize":"20px","lineHeight":"44px"}'>{{ title }}</div>
	
	<div class="info" :style='{"padding":"50px 50px 50px 280px","boxShadow":"none","margin":"0 auto 20px","borderRadius":"0","flexWrap":"wrap","background":"#ffffff","display":"flex","width":"100%","position":"relative","height":"260px"}'>
		<div :style='{"borderColor":"#efefef","color":"#333","borderWidth":"0 0 1px 0","display":"none","width":"100%","lineHeight":"44px","fontSize":"15px","borderStyle":"solid","height":"44px"}'>个人信息</div>
		<div :style='{"borderColor":"#efefef","top":"45px","left":"100px","borderWidth":"0","width":"150px","fontSize":"0","position":"absolute","borderStyle":"solid","height":"150px"}' v-if="userTableName=='jiaoshi'">
			<el-image :style='{"margin":"10px auto","borderColor":"#efefef","objectFit":"cover","borderRadius":"10px","borderWidth":"0 0 1px 0","display":"block","width":"100%","borderStyle":"solid","height":"100%"}' :src="sessionForm.zhaopian?baseUrl + sessionForm.zhaopian:require('@/assets/avator.png')" fit="cover"></el-image>
		</div>
		<div :style='{"borderColor":"#efefef","top":"45px","left":"100px","borderWidth":"0","width":"150px","fontSize":"0","position":"absolute","borderStyle":"solid","height":"150px"}' v-if="userTableName=='zhujiao'">
			<el-image :style='{"margin":"10px auto","borderColor":"#efefef","objectFit":"cover","borderRadius":"10px","borderWidth":"0 0 1px 0","display":"block","width":"100%","borderStyle":"solid","height":"100%"}' :src="sessionForm.touxiang?baseUrl + sessionForm.touxiang:require('@/assets/avator.png')" fit="cover"></el-image>
		</div>
		<div :style='{"borderColor":"#efefef","top":"45px","left":"100px","borderWidth":"0","width":"150px","fontSize":"0","position":"absolute","borderStyle":"solid","height":"150px"}' v-if="userTableName=='xuesheng'">
			<el-image :style='{"margin":"10px auto","borderColor":"#efefef","objectFit":"cover","borderRadius":"10px","borderWidth":"0 0 1px 0","display":"block","width":"100%","borderStyle":"solid","height":"100%"}' :src="sessionForm.touxiang?baseUrl + sessionForm.touxiang:require('@/assets/avator.png')" fit="cover"></el-image>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='jiaoshi'">
			<span class="icon iconfont icon-shouye-zhihui" :style='{"padding":"0 5px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","display":"none","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"color":"#333","fontSize":"14px","display":"none"}'>教师工号</div>
			<div :style='{"fontSize":"24px","color":"#000","textAlign":"left","flex":1}'>{{sessionForm.jiaoshigonghao}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='jiaoshi'">
			<span class="icon iconfont icon-qita1" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>性别</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"15px","color":"#333","textAlign":"left","flex":1,"height":"50%"}'>{{sessionForm.xingbie}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='jiaoshi'">
			<span class="icon iconfont icon-baohuhaoma" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>教师姓名</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"15px","color":"#333","textAlign":"left","flex":1,"height":"50%"}'>{{sessionForm.jiaoshixingming}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","borderWidth":"0","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"75px"}' v-if="userTableName=='jiaoshi'">
			<span class="icon iconfont icon-shouye-zhihui" :style='{"padding":"0 5px","fontSize":"14px","color":"#333","display":"none"}'></span>
			<div :style='{"color":"#333","fontSize":"14px","display":"none"}'>职称</div>
			<div :style='{"fontSize":"16px","color":"#000","textAlign":"left","flex":1}'>{{sessionForm.zhicheng}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='jiaoshi'">
			<span class="icon iconfont icon-kuaijiezhifu" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>联系电话</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"14px","color":"#333","textAlign":"left","height":"50%"}'>{{sessionForm.lianxidianhua}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='zhujiao'">
			<span class="icon iconfont icon-shouye-zhihui" :style='{"padding":"0 5px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","display":"none","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"color":"#333","fontSize":"14px","display":"none"}'>助教工号</div>
			<div :style='{"fontSize":"24px","color":"#000","textAlign":"left","flex":1}'>{{sessionForm.zhujiaogonghao}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='zhujiao'">
			<span class="icon iconfont icon-qita1" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>性别</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"15px","color":"#333","textAlign":"left","flex":1,"height":"50%"}'>{{sessionForm.xingbie}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='zhujiao'">
			<span class="icon iconfont icon-baohuhaoma" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>职称</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"15px","color":"#333","textAlign":"left","flex":1,"height":"50%"}'>{{sessionForm.zhicheng}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","borderWidth":"0","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"75px"}' v-if="userTableName=='zhujiao'">
			<span class="icon iconfont icon-shouye-zhihui" :style='{"padding":"0 5px","fontSize":"14px","color":"#333","display":"none"}'></span>
			<div :style='{"color":"#333","fontSize":"14px","display":"none"}'>助教姓名</div>
			<div :style='{"fontSize":"16px","color":"#000","textAlign":"left","flex":1}'>{{sessionForm.zhujiaoxingming}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='zhujiao'">
			<span class="icon iconfont icon-kuaijiezhifu" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>联系电话</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"14px","color":"#333","textAlign":"left","height":"50%"}'>{{sessionForm.lianxidianhua}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='xuesheng'">
			<span class="icon iconfont icon-shouye-zhihui" :style='{"padding":"0 5px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","display":"none","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"color":"#333","fontSize":"14px","display":"none"}'>学号</div>
			<div :style='{"fontSize":"24px","color":"#000","textAlign":"left","flex":1}'>{{sessionForm.xuehao}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='xuesheng'">
			<span class="icon iconfont icon-qita1" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>姓名</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"15px","color":"#333","textAlign":"left","flex":1,"height":"50%"}'>{{sessionForm.xingming}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='xuesheng'">
			<span class="icon iconfont icon-baohuhaoma" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>性别</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"15px","color":"#333","textAlign":"left","flex":1,"height":"50%"}'>{{sessionForm.xingbie}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","borderWidth":"0","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"75px"}' v-if="userTableName=='xuesheng'">
			<span class="icon iconfont icon-shouye-zhihui" :style='{"padding":"0 5px","fontSize":"14px","color":"#333","display":"none"}'></span>
			<div :style='{"color":"#333","fontSize":"14px","display":"none"}'>手机</div>
			<div :style='{"fontSize":"16px","color":"#000","textAlign":"left","flex":1}'>{{sessionForm.shouji}}</div>
		</div>
		<div :style='{"padding":"0 0","borderColor":"#efefef","flexWrap":"wrap","borderWidth":"0","flexDirection":"column","display":"flex","width":"calc(100% / 3)","lineHeight":"40px","borderStyle":"solid","height":"50%"}' v-if="userTableName=='xuesheng'">
			<span class="icon iconfont icon-kuaijiezhifu" :style='{"padding":"0 0","margin":"10px","color":"#fff","borderRadius":"50%","textAlign":"center","background":"#57A7A5","width":"55px","fontSize":"24px","lineHeight":"55px","height":"55px"}'></span>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"16px","color":"#000","height":"50%"}'>班级</div>
			<div :style='{"width":"calc(100% - 75px)","fontSize":"14px","color":"#333","textAlign":"left","height":"50%"}'>{{sessionForm.banji}}</div>
		</div>
		
	</div>
	
    <el-tabs tab-position="left" :style='{"width":"100%","flexWrap":"wrap","background":"#fff","justifyContent":"center","display":"flex"}' @tab-click="handleClick">
      <el-tab-pane label="个人中心">
        <el-form class="center-preview-pv" ref="sessionForm" :model="sessionForm" :rules="rules" label-width="200px">
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='jiaoshi'" label="教师工号" prop="jiaoshigonghao">
            <el-input v-model="sessionForm.jiaoshigonghao" placeholder="教师工号" readonly></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='jiaoshi'" label="性别" prop="xingbie">
            <el-select v-model="sessionForm.xingbie" placeholder="请选择性别" >
              <el-option v-for="(item, index) in dynamicProp.xingbie" :key="index" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='jiaoshi'" label="教师姓名" prop="jiaoshixingming">
            <el-input v-model="sessionForm.jiaoshixingming" placeholder="教师姓名" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='jiaoshi'" label="照片" prop="zhaopian">
			<file-upload
			tip="点击上传照片"
			action="file/upload"
			:limit="1"
			:multiple="true"
			:fileUrls="sessionForm.zhaopian?sessionForm.zhaopian:''"
			@change="jiaoshizhaopianHandleAvatarSuccess"
			></file-upload>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='jiaoshi'" label="职称" prop="zhicheng">
            <el-input v-model="sessionForm.zhicheng" placeholder="职称" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='jiaoshi'" label="联系电话" prop="lianxidianhua">
            <el-input v-model="sessionForm.lianxidianhua" placeholder="联系电话" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='zhujiao'" label="助教工号" prop="zhujiaogonghao">
            <el-input v-model="sessionForm.zhujiaogonghao" placeholder="助教工号" readonly></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='zhujiao'" label="性别" prop="xingbie">
            <el-select v-model="sessionForm.xingbie" placeholder="请选择性别" >
              <el-option v-for="(item, index) in dynamicProp.xingbie" :key="index" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='zhujiao'" label="头像" prop="touxiang">
			<file-upload
			tip="点击上传头像"
			action="file/upload"
			:limit="1"
			:multiple="true"
			:fileUrls="sessionForm.touxiang?sessionForm.touxiang:''"
			@change="zhujiaotouxiangHandleAvatarSuccess"
			></file-upload>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='zhujiao'" label="职称" prop="zhicheng">
            <el-input v-model="sessionForm.zhicheng" placeholder="职称" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='zhujiao'" label="助教姓名" prop="zhujiaoxingming">
            <el-input v-model="sessionForm.zhujiaoxingming" placeholder="助教姓名" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='zhujiao'" label="联系电话" prop="lianxidianhua">
            <el-input v-model="sessionForm.lianxidianhua" placeholder="联系电话" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='xuesheng'" label="学号" prop="xuehao">
            <el-input v-model="sessionForm.xuehao" placeholder="学号" readonly></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='xuesheng'" label="姓名" prop="xingming">
            <el-input v-model="sessionForm.xingming" placeholder="姓名" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='xuesheng'" label="性别" prop="xingbie">
            <el-select v-model="sessionForm.xingbie" placeholder="请选择性别" >
              <el-option v-for="(item, index) in dynamicProp.xingbie" :key="index" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='xuesheng'" label="头像" prop="touxiang">
			<file-upload
			tip="点击上传头像"
			action="file/upload"
			:limit="1"
			:multiple="true"
			:fileUrls="sessionForm.touxiang?sessionForm.touxiang:''"
			@change="xueshengtouxiangHandleAvatarSuccess"
			></file-upload>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='xuesheng'" label="手机" prop="shouji">
            <el-input v-model="sessionForm.shouji" placeholder="手机" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' v-if="userTableName=='xuesheng'" label="班级" prop="banji">
            <el-input v-model="sessionForm.banji" placeholder="班级" ></el-input>
          </el-form-item>
          <el-form-item :style='{"padding":"0","margin":"0"}'>
            <el-button :style='{"border":"0","cursor":"pointer","padding":"0","margin":"0 20px 0 0","outline":"none","color":"rgba(255, 255, 255, 1)","borderRadius":"0","background":"#57A7A5","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px"}' type="primary" @click="onSubmit('sessionForm')">更新信息</el-button>
            <el-button :style='{"border":"none","cursor":"pointer","padding":"0","margin":"0","outline":"none","color":"#fff","borderRadius":"0","background":"#9E9E9E","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px"}' type="danger" @click="logout">退出登录</el-button>
          </el-form-item>
        </el-form>
      </el-tab-pane>
	  <el-tab-pane label="修改密码">
		<el-form class="center-preview-pv" ref="passwordForm" :model="passwordForm" :rules="passwordRules" label-width="200px">
			<el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' label="原密码" prop="password">
			  <el-input type="password" v-model="passwordForm.password" placeholder="原密码"></el-input>
			</el-form-item>
			<el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' label="新密码" prop="newpassword">
			  <el-input type="password" v-model="passwordForm.newpassword" placeholder="新密码"></el-input>
			</el-form-item>
			<el-form-item :style='{"padding":"10px","margin":"0 0 10px","background":"none"}' label="确认密码" prop="repassword">
			  <el-input type="password" v-model="passwordForm.repassword" placeholder="确认密码"></el-input>
			</el-form-item>
			<el-form-item :style='{"padding":"0","margin":"0"}'>
			  <el-button :style='{"border":"0","cursor":"pointer","padding":"0","margin":"0 20px 0 0","outline":"none","color":"rgba(255, 255, 255, 1)","borderRadius":"0","background":"#57A7A5","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px"}' type="primary" @click="updatePassword">修改密码</el-button>
			</el-form-item>
		</el-form>
	  </el-tab-pane>
		<el-tab-pane v-for="(item,index) in menuList" :key="index" v-if="hasBack(item.menu)" :label="item.child[0].menu" :name="item.child[0].tableName"></el-tab-pane>
      <el-tab-pane label="我的发布"></el-tab-pane>
      <el-tab-pane label="学习测试记录"></el-tab-pane>
      <el-tab-pane label="错题本"></el-tab-pane>
      <el-tab-pane label="我的收藏"></el-tab-pane>
    </el-tabs>

</div>
</template>

<script>
  import config from '@/config/config'
  import menu from '@/config/menu'
  import Vue from 'vue'
  export default {
    //数据集合
    data() {
      return {
        title: '个人中心',
        baseUrl: config.baseUrl,
        sessionForm: {},
		passwordForm: {},
		passwordRules: {
			password: [
				{
					required: true,
					message: "密码不能为空",
					trigger: "blur"
				}
			],
			newpassword: [
				{
					required: true,
					message: "新密码不能为空",
					trigger: "blur"
				}
			],
			repassword: [
				{
					required: true,
					message: "确认密码不能为空",
					trigger: "blur"
				}
			]
		},
        rules: {},
		menuList: [],
        disabled: false,
        uploadUrl: config.baseUrl + 'file/upload',
        imageUrl: '',
        headers: {Token: localStorage.getItem('frontToken')},
        userTableName: localStorage.getItem('UserTableName'),
        dynamicProp: {},
      }
    },
    created() {
		let menus = menu.list()
		for(let x in menus){
			if(menus[x].tableName == this.userTableName){
				this.menuList = menus[x].backMenu
			}
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'jiaoshigonghao', null);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'mima', null);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'xingbie', null);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'jiaoshixingming', null);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'zhaopian', null);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'zhicheng', null);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.sessionForm, 'lianxidianhua', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'zhujiaogonghao', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'mima', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'xingbie', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'touxiang', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'zhicheng', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'zhujiaoxingming', null);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.sessionForm, 'lianxidianhua', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'xuehao', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'mima', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'xingming', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'xingbie', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'touxiang', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'shouji', null);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.sessionForm, 'banji', null);
		}

		if ('jiaoshi' == this.userTableName&&this.rules['jiaoshigonghao']){
			this.rules['jiaoshigonghao'].push({ required: true, message: '请输入教师工号', trigger: 'blur' })
		}else if('jiaoshi' == this.userTableName&&!this.rules['jiaoshigonghao']) {
			this.$set(this.rules, 'jiaoshigonghao', [{ required: true, message: '请输入教师工号', trigger: 'blur' }]);
		}
		if ('jiaoshi' == this.userTableName&&this.rules['mima']){
			this.rules['mima'].push({ required: true, message: '请输入密码', trigger: 'blur' })
		}else if('jiaoshi' == this.userTableName&&!this.rules['mima']) {
			this.$set(this.rules, 'mima', [{ required: true, message: '请输入密码', trigger: 'blur' }]);
		}
		if ('jiaoshi' == this.userTableName&&this.rules['jiaoshixingming']){
			this.rules['jiaoshixingming'].push({ required: true, message: '请输入教师姓名', trigger: 'blur' })
		}else if('jiaoshi' == this.userTableName&&!this.rules['jiaoshixingming']) {
			this.$set(this.rules, 'jiaoshixingming', [{ required: true, message: '请输入教师姓名', trigger: 'blur' }]);
		}
		if ('jiaoshi' == this.userTableName) {
			this.$set(this.rules, 'lianxidianhua', [{ required: false, validator: this.$validate.isMobile, trigger: 'blur' }]);
		}
		if ('zhujiao' == this.userTableName&&this.rules['zhujiaogonghao']){
			this.rules['zhujiaogonghao'].push({ required: true, message: '请输入助教工号', trigger: 'blur' })
		}else if('zhujiao' == this.userTableName&&!this.rules['zhujiaogonghao']) {
			this.$set(this.rules, 'zhujiaogonghao', [{ required: true, message: '请输入助教工号', trigger: 'blur' }]);
		}
		if ('zhujiao' == this.userTableName&&this.rules['mima']){
			this.rules['mima'].push({ required: true, message: '请输入密码', trigger: 'blur' })
		}else if('zhujiao' == this.userTableName&&!this.rules['mima']) {
			this.$set(this.rules, 'mima', [{ required: true, message: '请输入密码', trigger: 'blur' }]);
		}
		if ('zhujiao' == this.userTableName) {
			this.$set(this.rules, 'lianxidianhua', [{ required: false, validator: this.$validate.isMobile, trigger: 'blur' }]);
		}
		if ('xuesheng' == this.userTableName&&this.rules['xuehao']){
			this.rules['xuehao'].push({ required: true, message: '请输入学号', trigger: 'blur' })
		}else if('xuesheng' == this.userTableName&&!this.rules['xuehao']) {
			this.$set(this.rules, 'xuehao', [{ required: true, message: '请输入学号', trigger: 'blur' }]);
		}
		if ('xuesheng' == this.userTableName&&this.rules['mima']){
			this.rules['mima'].push({ required: true, message: '请输入密码', trigger: 'blur' })
		}else if('xuesheng' == this.userTableName&&!this.rules['mima']) {
			this.$set(this.rules, 'mima', [{ required: true, message: '请输入密码', trigger: 'blur' }]);
		}
		if ('xuesheng' == this.userTableName&&this.rules['xingming']){
			this.rules['xingming'].push({ required: true, message: '请输入姓名', trigger: 'blur' })
		}else if('xuesheng' == this.userTableName&&!this.rules['xingming']) {
			this.$set(this.rules, 'xingming', [{ required: true, message: '请输入姓名', trigger: 'blur' }]);
		}
		if ('xuesheng' == this.userTableName) {
			this.$set(this.rules, 'shouji', [{ required: false, validator: this.$validate.isMobile, trigger: 'blur' }]);
		}

      this.init();
      this.sessionForm = JSON.parse(localStorage.getItem('sessionForm'))
    },
    //方法集合
    methods: {
      init() {
        if ('jiaoshi' == this.userTableName) {
          this.dynamicProp.xingbie = '男,女'.split(',');
        }
        if ('zhujiao' == this.userTableName) {
          this.dynamicProp.xingbie = '男,女'.split(',');
        }
        if ('xuesheng' == this.userTableName) {
          this.dynamicProp.xingbie = '男,女'.split(',');
        }
      },
	  setSession(){
		  localStorage.setItem('sessionForm',JSON.stringify(this.sessionForm))
	  },
      onSubmit(formName) {
		if(`jiaoshi` == this.userTableName && this.sessionForm.zhaopian!=null){
			this.sessionForm.zhaopian = this.sessionForm.zhaopian.replace(new RegExp(this.$config.baseUrl,"g"),"");
		}
		if(`zhujiao` == this.userTableName && this.sessionForm.touxiang!=null){
			this.sessionForm.touxiang = this.sessionForm.touxiang.replace(new RegExp(this.$config.baseUrl,"g"),"");
		}
		if(`xuesheng` == this.userTableName && this.sessionForm.touxiang!=null){
			this.sessionForm.touxiang = this.sessionForm.touxiang.replace(new RegExp(this.$config.baseUrl,"g"),"");
		}
        this.$refs[formName].validate((valid) => {
			if (valid) {
				this.$http.post(this.userTableName + '/update', this.sessionForm).then(res => {
					if (res.data.code == 0) {
						this.setSession()
						this.$message({
							message: '更新成功',
							type: 'success',
							duration: 1500
						});
					}
				});
			} else {
				return false;
			}
        });
      },
      jiaoshizhaopianHandleAvatarSuccess(fileUrls) {
        this.sessionForm.zhaopian = fileUrls;
      },
      zhujiaotouxiangHandleAvatarSuccess(fileUrls) {
        this.sessionForm.touxiang = fileUrls;
      },
      xueshengtouxiangHandleAvatarSuccess(fileUrls) {
        this.sessionForm.touxiang = fileUrls;
      },
      handleClick(tab, event) {
        switch(event.target.outerText) {
          case '个人中心':
            tab.$router.push('/index/center');
            break;
          case '修改密码':
            this.passwordForm = {
				password: '',
				newpassword: '',
				repassword: '',
			}
			this.$forceUpdate()
            break;
          case '我的发布':
            tab.$router.push('/index/myForumList');
            break;
          case '学习测试记录':
            tab.$router.push('/index/examList');
            break;
          case '错题本':
            tab.$router.push('/index/examRecord/0');
            break;
          case '我的收藏':
            localStorage.setItem('storeupType', 1);
            tab.$router.push('/index/storeup');
            break;
		  default:
		  	tab.$router.push(`/index/${tab.name}?centerType=1`);
        }

        this.title = event.target.outerText;
      },
	  async updatePassword(){
			this.$refs["passwordForm"].validate(async valid => {
				if (valid) {
					var password = "";
					if (this.sessionForm.mima) {
						password = this.sessionForm.mima;
					} else if (this.sessionForm.password) {
						password = this.sessionForm.password;
					}
					if (this.passwordForm.password != password) {
						this.$message.error("原密码错误");
						return;
					}
					if (this.passwordForm.newpassword != this.passwordForm.repassword) {
						this.$message.error("两次密码输入不一致");
						return;
					}
					if (this.passwordForm.newpassword == this.passwordForm.password) {
						this.$message.error("新密码与原密码相同！");
						return;
					}
					if (this.userTableName == 'zhujiao') {
					}
					if (this.userTableName == 'xuesheng') {
					}
					this.sessionForm.password = this.passwordForm.newpassword;
					this.sessionForm.mima = this.passwordForm.newpassword;
					this.$http.post(`${this.userTableName}/update`,this.sessionForm).then(({data})=>{
						if (data && data.code === 0) {
							this.$message({
								message: "修改密码成功,下次登录系统生效",
								type: "success",
								duration: 1500,
								onClose: () => {
								}
							});
							this.setSession()
						} else {
							this.$message.error(data.msg);
						}
					});
				}
			})
	  },
      logout() {
        localStorage.clear();
        Vue.http.headers.common['Token'] = "";
        this.$router.push('/index/home');
        this.activeIndex = '0'
        localStorage.setItem('keyPath', this.activeIndex)
        this.$forceUpdate()
        this.$message({
            message: '登出成功',
            type: 'success',
            duration: 1500,
        });
      },
	  hasBack(name){
		  switch(name){
			case '试题库管理':
				return false
				break;
			case '试题管理':
				return false
				break;
			case '我的收藏管理':
				return false
				break;
			default:
				return true
		  }
	  }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .center-preview {
  
    .el-tabs {
      & /deep/ .el-tabs__header {
		.el-tabs__nav{
			overflow: auto;
		}
		::-webkit-scrollbar {
		  -webkit-appearance: none;
		  width: 6px;
		  height: 6px;
		}
		::-webkit-scrollbar-track {
		  background: rgba(0, 0, 0, 0.1);
		  border-radius: 0;
		}
		::-webkit-scrollbar-thumb {
		  cursor: pointer;
		  border-radius: 5px;
		  background: rgba(0, 0, 0, 0.15);
		  transition: color 0.2s ease;
		}
		::-webkit-scrollbar-thumb:hover {
		  background: rgba(0, 0, 0, 0.3);
		}
        .el-tabs__nav-wrap {
          margin: 0;
  
          &::after {
            content: none;
          }
        }
  
        .el-tabs__active-bar {
          display: none !important;
        }
      }
  
      .center-preview-pv {
        .el-date-editor.el-input {
          width: auto;
        }
  
        .balance {
          .el-input {
            width: auto;
          }
        }
      }
    }
  }
  
  .center-preview .el-tabs /deep/ .el-tabs__header {
	padding: 0;
	margin: 0 auto;
	background: #57A7A5;
	width: 100%;
	border-color: #eee;
	border-width: 0;
	position: relative;
	float: left;
	border-style: solid;
  }
  
  .center-preview .el-tabs /deep/ .el-tabs__header .el-tabs__item {
  	padding: 0 30px;
  	color: #000;
  	background: #57A7A5;
  	font-weight: 500;
  	display: inline-block;
  	font-size: 14px;
  	line-height: 60px;
  	position: relative;
  	text-align: center;
  	height: 60px;
  }
  
  .center-preview .el-tabs /deep/ .el-tabs__header .el-tabs__item:hover {
  	padding: 0 30px;
  	color: #fff;
  	background: #57A7A5;
  	font-weight: 500;
  	display: inline-block;
  	font-size: 14px;
  	line-height: 60px;
  	position: relative;
  	text-align: center;
  	height: 60px;
  }
  
  .center-preview .el-tabs /deep/ .el-tabs__header .el-tabs__item.is-active {
  	padding: 0 30px;
  	color: #fff;
  	background: #57A7A5;
  	font-weight: 500;
  	display: inline-block;
  	font-size: 14px;
  	line-height: 60px;
  	position: relative;
  	text-align: center;
  	height: 60px;
  }
  
  .center-preview .el-tabs /deep/ .el-tabs__content {
  	padding: 10px;
  	background: #fff;
  	width: 100%;
  }
  .center-preview .el-tabs /deep/ .el-tabs__content .el-tab-pane {
  }
  
  .center-preview-pv .el-form-item /deep/ .el-form-item__label {
  	padding: 0 10px 0 0;
  	color: #000;
  	font-weight: 500;
  	width: 200px;
  	font-size: 14px;
  	line-height: 40px;
  	text-align: right;
  }
  
  .center-preview-pv .el-form-item .el-form-item__content {
    margin-left: 200px;
  }
  
  .center-preview-pv .el-input /deep/ .el-input__inner {
  	border: 1px solid #E2E3E5;
  	border-radius: 0;
  	padding: 0 12px;
  	box-shadow: none;
  	outline: none;
  	color: #000;
  	width: 500px;
  	font-size: 14px;
  	height: 40px;
  }
  
  .center-preview-pv .el-select /deep/ .el-input__inner {
  	border: 1px solid #E2E3E5;
  	border-radius: 0;
  	padding: 0 12px;
  	box-shadow: none;
  	outline: none;
  	color: #000;
  	width: 500px;
  	font-size: 14px;
  	height: 40px;
  }
  
  .center-preview-pv .el-date-editor /deep/ .el-input__inner {
  	border: 1px solid #E2E3E5;
  	border-radius: 0;
  	padding: 0 10px 0 30px;
  	box-shadow: none;
  	outline: none;
  	color: #000;
  	width: 500px;
  	font-size: 14px;
  	height: 40px;
  }
  
  .center-preview-pv /deep/ .avatar-uploader-icon {
  	border: 1px solid #E2E3E5;
  	cursor: pointer;
  	border-radius: 0;
  	color: #000;
  	width: 200px;
  	font-size: 32px;
  	line-height: 60px;
  	text-align: center;
  	height: 60px;
  }
  
  .center-preview-pv .el-form-item.balance /deep/ .el-input__inner {
  	border: 1px solid #E2E3E5;
  	border-radius: 0;
  	padding: 0 12px;
  	box-shadow: none;
  	outline: none;
  	color: #000;
  	display: inline-block;
  	width: 390px;
  	font-size: 14px;
  	height: 40px;
  }
</style>
